﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uko5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_vypoc_Click(object sender, EventArgs e)
        {
            try
            {
                int cislo = int.Parse(comboBox1.SelectedItem.ToString());
                int c1 = int.Parse(textBox1.Text);
                int c2 = int.Parse(textBox2.Text);
                int c3 = int.Parse(textBox3.Text);
                int vys = 1;
                int vys2 = 1;
                int vys3 = 1;
                string label = comboBox1.SelectedItem.ToString();
                label1.Text = label;
                if(cislo == 1)
                {
                    vys = c1;
                    vys2 = c2;
                    vys3 = c3;
                }
                if(cislo == 2)
                {
                    vys2 = c2 * c2;
                    vys = c1 * c1;
                    vys3 = c3 * c3;
                }
                if(cislo == 3)
                {
                    vys3 = c3 * c3 * c3;
                    vys = c1 * c1 * c1;
                    vys2 = c2 * c2 * c2;

                }
                textBox1.Text = vys.ToString();
                textBox2.Text = vys2.ToString();
                textBox3.Text = vys3.ToString();
            }
            catch { MessageBox.Show("ERROR"); }
        }
    }
}
